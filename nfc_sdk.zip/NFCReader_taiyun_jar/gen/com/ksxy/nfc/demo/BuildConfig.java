/** Automatically generated file. DO NOT MODIFY */
package com.ksxy.nfc.demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}